<?php $__env->startSection('content'); ?>

    <div class="row">

    <div class="col-sm-4">

	<img src="<?php echo e($arrayPeliculas->poster); ?>" class="w-100" />

    </div>
    <div class="col-sm-8">

		<h1><?php echo e($arrayPeliculas['title']); ?></h1>
			<h5>Año:<?php echo e($arrayPeliculas['year']); ?></h2>
			<h5>Director:<?php echo e($arrayPeliculas['director']); ?></h3>
				<br>
			        <p>
			        	<b>Resumen:</b> <?php echo e($arrayPeliculas->synopsis); ?>

			        </p>
		        <br>
		        <?php if($arrayPeliculas->rented): ?>
				<p><b>Estado:</b>Película actualmente alquilada</p>
				<br>
						<form action="<?php echo e(action('CatalogController@putReturn', $arrayPeliculas->id)); ?>" 
						    method="POST" style="display:inline">
						    <?php echo e(method_field('PUT')); ?>

						    <?php echo e(csrf_field()); ?>

						    <button type="submit" class="btn btn-warning" style="display:inline">
						    	 <span class="glyphicon glyphicon-pause"></span>Devolver película
						    </button>
						</form>
						
						<form action="<?php echo e(action('CatalogController@deleteMovie', $arrayPeliculas->id)); ?>" 
						    method="POST" style="display:inline">
						    <?php echo e(method_field('PUT')); ?>

						    <?php echo e(csrf_field()); ?>

						    <button type="submit" class="btn btn-danger" style="display:inline">
						        <span class="glyphicon glyphicon-trash"></span>Eliminar Pelicula
						    </button>
						</form>

						<a href="<?php echo e(url('catalog/edit/'.$arrayPeliculas->id)); ?>" class="btn btn-info"><span class="glyphicon glyphicon-pencil"></span> Editar Pelicula</a>
						
						<a href="<?php echo e(url('/catalog')); ?>" class="btn btn-default"><span class="glyphicon glyphicon-chevron-left"></span> Volver al Listado</a>		
		        <?php else: ?>
		        <p><b>Estado:</b>Película disponible</p>
		        <br>
		        		<form action="<?php echo e(action('CatalogController@putRent', $arrayPeliculas->id)); ?>" 
						    method="POST" style="display:inline">
						    <?php echo e(method_field('PUT')); ?>

						    <?php echo e(csrf_field()); ?>

						    <button type="submit" class="btn btn-success" style="display:inline">
						    	 <span class="glyphicon glyphicon-play"></span>Alquilar Pelicula
						    </button>
						</form>

						<form action="<?php echo e(action('CatalogController@deleteMovie', $arrayPeliculas->id)); ?>" 
						    method="POST" style="display:inline">
						    <?php echo e(method_field('PUT')); ?>

						    <?php echo e(csrf_field()); ?>

						    <button type="submit" class="btn btn-danger" style="display:inline">
						        <span class="glyphicon glyphicon-trash"></span>Eliminar Pelicula
						    </button>
						</form>
						
						<a href="<?php echo e(url('catalog/edit/'.$arrayPeliculas->id)); ?>" class="btn btn-info"><span class="glyphicon glyphicon-pencil"></span> Editar Pelicula</a>
						<a href="<?php echo e(url('/catalog')); ?>" class="btn btn-default"><span class="glyphicon glyphicon-chevron-left"></span> Volver al Listado</a>		


		        <?php endif; ?>	        
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\phpMyAdmin\htdocs\videoclub\resources\views/catalog/show.blade.php ENDPATH**/ ?>